import { useState, useCallback } from "react";

// ── 2026 KENTUCKY DERBY CONFIRMED FIELD ──
// Post positions updated after scratches: Right to Party (5), Silent Tactic (13), Fulleffort (20) scratched
// Replacements: Robusta (5), Great White (13), Ocelli (20)
const FIELD = [
  { post:1,  name:"Renegade",        odds:"5-1",   jockey:"Irad Ortiz Jr.",   trainer:"Todd Pletcher",   style:"Closer",  color:"#C8102E", beyer:98,  note:"Morning-line fav, Post 1 curse (no winner since 1986), best jockey in field" },
  { post:2,  name:"Albus",           odds:"30-1",  jockey:"Manny Franco",     trainer:"Riley Mott",      style:"Stalker", color:"#1D3557", beyer:88,  note:"Longshot, son of Sovereignty's trainer dynasty" },
  { post:3,  name:"Intrepido",       odds:"20-1",  jockey:"Hector Berrios",   trainer:"Jeff Mullins",    style:"Presser", color:"#2E8B57", beyer:91,  note:"Fastest 5-furlong Churchill work since 2012 (57 sec)" },
  { post:4,  name:"Litmus Test",     odds:"15-1",  jockey:"Martin Garcia",    trainer:"Bob Baffert",     style:"Stalker", color:"#8B4513", beyer:93,  note:"Baffert's best chance, consistent Grade 1 performer" },
  { post:5,  name:"Robusta",         odds:"50-1",  jockey:"Emisael Jaramillo",trainer:"Doug O'Neill",    style:"Closer",  color:"#556B2F", beyer:84,  note:"Alternate in after Right to Party scratch" },
  { post:6,  name:"Commandment",     odds:"6-1",   jockey:"Luis Saez",        trainer:"Brad Cox",        style:"Stalker", color:"#B8860B", beyer:101, note:"4-for-5, Florida Derby winner, all wins on fast track" },
  { post:7,  name:"Danon Bourbon",   odds:"30-1",  jockey:"Florent Geroux",   trainer:"Yoshito Yahagi",  style:"Presser", color:"#4682B4", beyer:89,  note:"Japanese contender, UAE Derby runner" },
  { post:8,  name:"So Happy",        odds:"6-1",   jockey:"Javier Castellano",trainer:"Mark Casse",      style:"Closer",  color:"#9932CC", beyer:97,  note:"Casse 0-11 Derby record but horse has strong figures" },
  { post:9,  name:"The Puma",        odds:"5-1",   jockey:"Jose Ortiz",       trainer:"Chad Brown",      style:"Closer",  color:"#FF6B35", beyer:99,  note:"Co-favorite, Tampa Bay Derby winner, strong closer" },
  { post:10, name:"Wonder Dean",     odds:"20-1",  jockey:"Yutaka Take",      trainer:"Naosuke Sugai",   style:"Closer",  color:"#DC143C", beyer:90,  note:"Japanese horse, Post 10 historically strong (9 Derby wins)" },
  { post:11, name:"Incredibolt",     odds:"20-1",  jockey:"Jaime Torres",     trainer:"Riley Mott",      style:"Presser", color:"#20B2AA", beyer:92,  note:"Riley Mott's second entry, improving form" },
  { post:12, name:"Chief Wallabee",  odds:"8-1",   jockey:"Junior Alvarado",  trainer:"Bill Mott",       style:"Stalker", color:"#D2691E", beyer:95,  note:"Bill Mott trained Sovereignty (2025 winner), strong angle" },
  { post:13, name:"Great White",     odds:"50-1",  jockey:"TBD",              trainer:"TBD",             style:"Closer",  color:"#708090", beyer:82,  note:"Alternate in after Silent Tactic scratch" },
  { post:14, name:"Potente",         odds:"20-1",  jockey:"Juan Hernandez",   trainer:"Bob Baffert",     style:"Presser", color:"#8B0000", beyer:90,  note:"Baffert's second entry, European influence" },
  { post:15, name:"Emerging Market", odds:"15-1",  jockey:"Flavien Prat",     trainer:"Chad Brown",      style:"Closer",  color:"#006400", beyer:94,  note:"Chad Brown's top closer, Wood Memorial placed" },
  { post:16, name:"Pavlovian",       odds:"30-1",  jockey:"Edwin Maldonado",  trainer:"Doug O'Neill",    style:"Closer",  color:"#4B0082", beyer:87,  note:"Longshot with tactical speed" },
  { post:17, name:"Further Ado",     odds:"6-1",   jockey:"John Velazquez",   trainer:"Brad Cox",        style:"Stalker", color:"#B22222", beyer:107, note:"Blue Grass by 11L, top Beyer (107) in field, HOF jockey" },
  { post:18, name:"Golden Tempo",    odds:"30-1",  jockey:"Jose Ortiz",       trainer:"Cherie Devaux",   style:"Presser", color:"#DAA520", beyer:88,  note:"French-trained, outside post suits his style" },
  { post:19, name:"Six Speed",       odds:"50-1",  jockey:"TBD",              trainer:"Bhupat Seemar",   style:"Closer",  color:"#2F4F4F", beyer:83,  note:"UAE Derby, international qualifier" },
  { post:20, name:"Ocelli",          odds:"50-1",  jockey:"Joe Ramos",        trainer:"D.W. Beckman",    style:"Closer",  color:"#696969", beyer:87,  note:"Alternate in, Wood Memorial third (25pts), deep closer" },
];

const TRACK_CONDITIONS = ["Fast", "Good", "Yielding", "Muddy", "Sloppy", "Frozen"];
const STYLE_COLORS = { Closer:"#FF6B35", Stalker:"#3DFFA0", Presser:"#38BDF8", Frontrunner:"#FFD700" };

// Fractional odds → implied probability
function oddsToProb(odds) {
  if (!odds || odds === "SCR") return 0;
  const clean = odds.replace("-1","").trim();
  const parts = clean.split("-");
  if (parts.length === 2) {
    const [n, d] = parts.map(Number);
    if (!isNaN(n) && !isNaN(d) && d > 0) return d / (n + d);
  }
  return 0;
}

function probToOdds(p) {
  if (p <= 0) return "N/A";
  const d = 1; const n = ((1 - p) / p);
  return `${n.toFixed(0)}-1`;
}

async function callAPI(endpoint, body) {
  const res = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

const S = {
  app: {
    minHeight: "100vh",
    background: "linear-gradient(160deg, #0D0800 0%, #1A0F00 40%, #0D0500 100%)",
    fontFamily: "'Georgia', 'Times New Roman', serif",
    color: "#F5E6C8",
  },
  gold: "#C9A84C",
  rose: "#C8102E",
  green: "#2D6A2D",
  cream: "#F5E6C8",
  card: {
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(201,168,76,0.2)",
    borderRadius: 8,
    padding: 16,
  },
  inp: {
    width: "100%",
    padding: "8px 12px",
    borderRadius: 6,
    background: "rgba(255,255,255,0.07)",
    border: "1px solid rgba(201,168,76,0.3)",
    color: "#F5E6C8",
    fontSize: 13,
    fontFamily: "Georgia, serif",
    boxSizing: "border-box",
  },
  lbl: {
    fontSize: 10,
    color: "#8a7a5a",
    textTransform: "uppercase",
    letterSpacing: "0.12em",
    display: "block",
    marginBottom: 4,
  },
};

export default function App() {
  const [view, setView]                   = useState("field");
  const [trackCondition, setTrackCondition] = useState("Fast");
  const [selectedHorse, setSelectedHorse]   = useState(null);
  const [prediction, setPrediction]         = useState(null);
  const [raceAnalysis, setRaceAnalysis]     = useState(null);
  const [predLoading, setPredLoading]       = useState(false);
  const [raceLoading, setRaceLoading]       = useState(false);
  const [notes, setNotes]                   = useState("");
  const [error, setError]                   = useState(null);
  const [bets, setBets]                     = useState([]);
  const [betForm, setBetForm]               = useState({ horse:"", betType:"Win", units:"", odds:"", result:"pending", note:"" });

  // ── Predict single horse ──
  const predictHorse = useCallback(async (horse) => {
    setSelectedHorse(horse);
    setPrediction(null);
    setPredLoading(true);
    setError(null);
    setView("predict");
    try {
      const prompt = `Analyze this horse for the 152nd Kentucky Derby (May 2, 2026, Churchill Downs):

Horse: ${horse.name}
Post Position: ${horse.post} of 20
Morning Line Odds: ${horse.odds}
Jockey: ${horse.jockey}
Trainer: ${horse.trainer}
Racing Style: ${horse.style}
Best Beyer Speed Figure: ${horse.beyer}
Track Condition: ${trackCondition}
Key Note: ${horse.note}
${notes ? `Additional context: ${notes}` : ""}

Historical context: Post ${horse.post} has produced ${horse.post === 5 ? "10 (most ever)" : horse.post === 10 ? "9" : horse.post === 1 ? "5 (last winner Ferdinand 1986)" : "several"} Derby winners.
The track is forecast: ${trackCondition}, high 61°F, mostly sunny.

Provide expert handicapping analysis.`;
      const result = await callAPI("/api/predict", { prompt });
      setPrediction(result);
    } catch (e) {
      setError(e.message);
    } finally {
      setPredLoading(false);
    }
  }, [trackCondition, notes]);

  // ── Analyze full race ──
  const analyzeFullRace = useCallback(async () => {
    setRaceLoading(true);
    setError(null);
    try {
      const result = await callAPI("/api/analyze-race", {
        horses: FIELD,
        trackCondition,
        notes,
      });
      setRaceAnalysis(result);
      setView("analysis");
    } catch (e) {
      setError(e.message);
    } finally {
      setRaceLoading(false);
    }
  }, [trackCondition, notes]);

  // ── Bet tracker ──
  const safeNum = v => { const n = parseFloat(v); return isNaN(n) ? 0 : n; };
  const addBet = () => {
    if (!betForm.horse) return;
    const units = safeNum(betForm.units);
    if (units <= 0) return;
    setBets(p => [...p, { ...betForm, id: Date.now(), units }]);
    setBetForm({ horse:"", betType:"Win", units:"", odds:"", result:"pending", note:"" });
  };
  const updateResult = (id, r) => setBets(p => p.map(b => b.id===id ? {...b, result:r} : b));
  const deleteBet = id => setBets(p => p.filter(b => b.id!==id));

  const stats = (() => {
    const won  = bets.filter(b => b.result==="won");
    const lost = bets.filter(b => b.result==="lost");
    const risked = bets.reduce((s,b) => s+safeNum(b.units), 0);
    const wonU = won.reduce((s,b) => {
      const parts = b.odds.split("-").map(Number);
      const mult = parts.length===2 && parts[1]>0 ? parts[0]/parts[1] : 1;
      return s + safeNum(b.units) * mult;
    }, 0);
    const lostU = lost.reduce((s,b) => s+safeNum(b.units), 0);
    const net = wonU - lostU;
    return { won:won.length, lost:lost.length, pending:bets.filter(b=>b.result==="pending").length,
             net: isNaN(net)?0:net, roi: risked>0?((net/risked)*100):0, risked };
  })();

  const TABS = ["field","predict","analysis","tracker"];

  return (
    <div style={S.app}>
      {/* ── HEADER ── */}
      <div style={{
        borderBottom: "1px solid rgba(201,168,76,0.3)",
        background: "rgba(10,5,0,0.92)",
        position: "sticky", top:0, zIndex:100,
        backdropFilter: "blur(8px)",
      }}>
        <div style={{ maxWidth:1140, margin:"0 auto", padding:"14px 24px 0" }}>
          <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:2, flexWrap:"wrap" }}>
            <span style={{ fontSize:28 }}>🏇</span>
            <div style={{ flex:1 }}>
              <h1 style={{
                margin:0, fontSize:"clamp(16px,3vw,26px)", fontWeight:700,
                letterSpacing:"0.08em", textTransform:"uppercase",
                background:`linear-gradient(90deg, ${S.gold}, #fff8e7, ${S.gold})`,
                WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent",
              }}>
                Kentucky Derby AI Predictor
              </h1>
              <p style={{ margin:"1px 0 0", fontSize:10, color:"#7a6a4a", letterSpacing:"0.15em", textTransform:"uppercase" }}>
                152nd Run for the Roses · May 2, 2026 · Churchill Downs · Post Time 6:57 PM ET
              </p>
            </div>
            {/* Track + weather */}
            <div style={{ display:"flex", gap:10, alignItems:"center", flexWrap:"wrap" }}>
              <div style={{ fontSize:11, color:"#8a7a5a", textAlign:"right" }}>
                <div>☀️ 61°F · Mostly Sunny · 20% Rain</div>
                <div style={{ color:"#C9A84C", fontWeight:700 }}>Track: {trackCondition}</div>
              </div>
              <select value={trackCondition} onChange={e=>setTrackCondition(e.target.value)} style={{...S.inp,width:"auto",padding:"5px 10px",fontSize:11}}>
                {TRACK_CONDITIONS.map(t=><option key={t}>{t}</option>)}
              </select>
            </div>
            {bets.length>0 && (
              <div style={{ display:"flex", gap:10, fontSize:11 }}>
                <span style={{ color:"#6BFFB8" }}>W:{stats.won}</span>
                <span style={{ color:"#FF6B6B" }}>L:{stats.lost}</span>
                <span style={{ fontWeight:700, color:stats.net>=0?"#6BFFB8":"#FF6B6B" }}>
                  {stats.net>=0?"+":""}{stats.net.toFixed(2)}u
                </span>
              </div>
            )}
          </div>
          <div style={{ display:"flex", gap:0, marginTop:10 }}>
            {TABS.map(v=>(
              <button key={v} onClick={()=>setView(v)} style={{
                padding:"7px 18px", border:"none", cursor:"pointer",
                fontFamily:"Georgia,serif", fontSize:11, letterSpacing:"0.08em",
                textTransform:"uppercase", fontWeight:600, background:"transparent",
                color:view===v?S.gold:"#6b5a3a",
                borderBottom:view===v?`2px solid ${S.gold}`:"2px solid transparent",
              }}>
                {v==="field"?"🐎 Field":v==="predict"?"🔮 Predict":v==="analysis"?`🏆 AI Analysis${raceAnalysis?" ✓":""}` :`📊 Tracker${bets.length>0?` (${bets.length})`:""}`}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth:1140, margin:"0 auto", padding:"24px" }}>
        {error && (
          <div style={{ background:"rgba(255,80,80,0.1)", border:"1px solid rgba(255,80,80,0.3)", borderRadius:7, padding:"10px 14px", marginBottom:16, color:"#ff8080", fontSize:12 }}>
            ⚠️ {error}
          </div>
        )}

        {/* ═══ FIELD VIEW ═══ */}
        {view==="field" && (
          <div>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:20, flexWrap:"wrap", gap:12 }}>
              <div>
                <h2 style={{ margin:0, fontSize:17, color:S.gold }}>🐎 2026 Field — 20 Horses</h2>
                <p style={{ margin:"3px 0 0", fontSize:11, color:"#6b5a3a" }}>
                  Click any horse to get AI handicapping analysis · 3 scratches replaced by alternates
                </p>
              </div>
              <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                <div>
                  <label style={S.lbl}>Context / Notes</label>
                  <input id="notes" name="notes" value={notes} onChange={e=>setNotes(e.target.value)}
                    placeholder="Injury news, track bias, trainer angles..."
                    style={{...S.inp, width:280}} />
                </div>
                <div style={{ paddingTop:14 }}>
                  <button onClick={analyzeFullRace} disabled={raceLoading} style={{
                    padding:"9px 20px", borderRadius:4,
                    background:raceLoading?"rgba(201,168,76,0.1)":"linear-gradient(135deg,#C9A84C,#9a7a2c)",
                    border:"1px solid #C9A84C", color:raceLoading?"#C9A84C":"#0D0800",
                    fontSize:12, fontWeight:700, cursor:raceLoading?"not-allowed":"pointer",
                    fontFamily:"Georgia,serif",
                  }}>
                    {raceLoading?"Analyzing...":"⚡ AI Full Race Analysis"}
                  </button>
                </div>
              </div>
            </div>

            {/* Legend */}
            <div style={{ display:"flex", gap:16, marginBottom:16, flexWrap:"wrap" }}>
              {Object.entries(STYLE_COLORS).map(([style,color])=>(
                <div key={style} style={{ display:"flex", alignItems:"center", gap:5, fontSize:10, color:"#8a7a5a" }}>
                  <div style={{ width:8, height:8, borderRadius:"50%", background:color }} />
                  {style}
                </div>
              ))}
              <div style={{ fontSize:10, color:"#5a4a2a", marginLeft:"auto" }}>
                ⭐ Post 5: most wins (10) · Post 10: 9 wins · No winner from Post 1 since 1986
              </div>
            </div>

            {/* Horse grid */}
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))", gap:10 }}>
              {FIELD.map(horse => {
                const imp = oddsToProb(horse.odds);
                const isHot = parseFloat(horse.odds) <= 8;
                const isLong = parseFloat(horse.odds) >= 30;
                return (
                  <div key={horse.post} onClick={()=>predictHorse(horse)} style={{
                    ...S.card,
                    cursor:"pointer",
                    borderColor: selectedHorse?.post===horse.post ? S.gold : isHot ? "rgba(201,168,76,0.35)" : "rgba(201,168,76,0.12)",
                    background: selectedHorse?.post===horse.post ? "rgba(201,168,76,0.1)" : "rgba(255,255,255,0.03)",
                    transition:"all 0.15s",
                  }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
                      <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                        <div style={{
                          width:28, height:28, borderRadius:4, display:"flex", alignItems:"center", justifyContent:"center",
                          background:horse.color+"33", border:`1.5px solid ${horse.color}66`,
                          fontSize:12, fontWeight:700, color:horse.color, flexShrink:0,
                        }}>{horse.post}</div>
                        <div>
                          <div style={{ fontSize:14, fontWeight:700, color:"#F5E6C8", lineHeight:1.2 }}>{horse.name}</div>
                          <div style={{ fontSize:9, color:STYLE_COLORS[horse.style]||"#8a7a5a" }}>{horse.style}</div>
                        </div>
                      </div>
                      <div style={{ textAlign:"right" }}>
                        <div style={{
                          fontSize:14, fontWeight:700,
                          color: isHot?"#FFD700":isLong?"#8a7a5a":"#C9A84C"
                        }}>{horse.odds}</div>
                        <div style={{ fontSize:9, color:"#5a4a2a" }}>{(imp*100).toFixed(1)}% impl</div>
                      </div>
                    </div>
                    <div style={{ fontSize:10, color:"#7a6a4a", marginBottom:5 }}>
                      🧑 {horse.jockey} · 🎩 {horse.trainer}
                    </div>
                    <div style={{ fontSize:10, color:"#8a7a5a", lineHeight:1.4 }}>{horse.note}</div>
                    <div style={{ marginTop:6, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                      <div style={{ fontSize:9, color:"#5a4a2a" }}>Beyer: <span style={{ color:"#C9A84C", fontWeight:700 }}>{horse.beyer}</span></div>
                      <div style={{ fontSize:9, color:S.gold }}>→ Analyze</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ═══ PREDICT VIEW ═══ */}
        {view==="predict" && (
          <div style={{ maxWidth:740, margin:"0 auto" }}>
            <h2 style={{ margin:"0 0 16px", fontSize:17, color:S.gold }}>🔮 Horse Analysis</h2>

            {/* Horse selector */}
            <div style={{ ...S.card, padding:20, marginBottom:16 }}>
              <label htmlFor="horse-select" style={S.lbl}>Select Horse</label>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:12 }}>
                <select id="horse-select" name="horse" value={selectedHorse?.post||""} onChange={e=>{
                  const h = FIELD.find(x=>x.post===parseInt(e.target.value));
                  if (h) predictHorse(h);
                }} style={S.inp}>
                  {FIELD.map(h=><option key={h.post} value={h.post}>Post {h.post}: {h.name} ({h.odds})</option>)}
                </select>
                <select id="track-select" name="track" value={trackCondition} onChange={e=>setTrackCondition(e.target.value)} style={S.inp}>
                  {TRACK_CONDITIONS.map(t=><option key={t}>{t}</option>)}
                </select>
              </div>
              <div style={{ marginBottom:12 }}>
                <label htmlFor="predict-notes" style={S.lbl}>Injury / Context Notes</label>
                <input id="predict-notes" name="notes" value={notes} onChange={e=>setNotes(e.target.value)}
                  placeholder="e.g. Trainer reported horse worked well Wednesday, no concerns"
                  style={S.inp} />
              </div>
              <button onClick={()=>selectedHorse&&predictHorse(selectedHorse)} style={{
                width:"100%", padding:"10px", borderRadius:5,
                background:"linear-gradient(135deg,#C9A84C,#9a7a2c)",
                border:"none", color:"#0D0800", fontSize:13, fontWeight:700,
                cursor:"pointer", fontFamily:"Georgia,serif",
              }}>🔮 Analyze This Horse</button>
            </div>

            {/* Result */}
            {predLoading && (
              <div style={{ ...S.card, textAlign:"center", padding:"36px 20px" }}>
                <div style={{ fontSize:28, marginBottom:8 }}>🐎</div>
                <div style={{ color:S.gold, fontSize:13 }}>AI handicapper analyzing {selectedHorse?.name}...</div>
              </div>
            )}

            {prediction && !predLoading && selectedHorse && (
              <HorseAnalysis horse={selectedHorse} prediction={prediction}
                onAddBet={bet=>{setBets(p=>[...p,{...bet,id:Date.now()}]); setView("tracker");}} />
            )}
          </div>
        )}

        {/* ═══ RACE ANALYSIS VIEW ═══ */}
        {view==="analysis" && (
          <div>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:18, flexWrap:"wrap", gap:10 }}>
              <h2 style={{ margin:0, fontSize:17, color:S.gold }}>🏆 AI Full Race Analysis</h2>
              <button onClick={analyzeFullRace} disabled={raceLoading} style={{
                padding:"7px 16px", borderRadius:4,
                background:raceLoading?"rgba(201,168,76,0.1)":"rgba(201,168,76,0.15)",
                border:`1px solid ${S.gold}`, color:S.gold,
                fontSize:11, cursor:raceLoading?"not-allowed":"pointer", fontFamily:"Georgia,serif",
              }}>
                {raceLoading?"Re-analyzing...":"🔄 Re-analyze"}
              </button>
            </div>

            {raceLoading && (
              <div style={{ ...S.card, textAlign:"center", padding:"48px 20px" }}>
                <div style={{ fontSize:36, marginBottom:10 }}>🏇</div>
                <div style={{ color:S.gold, fontSize:14 }}>AI handicapper analyzing all 20 horses...</div>
                <div style={{ fontSize:11, color:"#5a4a2a", marginTop:6 }}>Evaluating pace, post position, pedigree, figures...</div>
              </div>
            )}

            {raceAnalysis && !raceLoading && (
              <div>
                {/* Winner + exacta/trifecta */}
                <div style={{
                  textAlign:"center", padding:"28px 20px", marginBottom:20,
                  background:"radial-gradient(ellipse at center,rgba(201,168,76,0.12),rgba(201,168,76,0.02) 70%)",
                  border:`1px solid rgba(201,168,76,0.4)`, borderRadius:12,
                }}>
                  <div style={{ fontSize:48, marginBottom:6 }}>🌹</div>
                  <p style={{ fontSize:10, color:"#8a7a5a", textTransform:"uppercase", letterSpacing:"0.2em", margin:"0 0 4px" }}>AI Predicted Winner</p>
                  <h1 style={{
                    fontSize:"clamp(26px,5vw,44px)", margin:"0 0 6px",
                    background:`linear-gradient(90deg,${S.gold},#fff8e7,${S.gold})`,
                    WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", fontWeight:700,
                  }}>
                    {raceAnalysis.winner}
                  </h1>
                  {raceAnalysis.winner && (() => {
                    const h = FIELD.find(x=>x.name===raceAnalysis.winner);
                    return h ? <p style={{ margin:"0 0 8px", fontSize:12, color:"#8a7a5a" }}>Post {h.post} · {h.odds} · {h.jockey}</p> : null;
                  })()}
                  {raceAnalysis.keyRace && (
                    <p style={{ margin:"10px auto 0", fontSize:12, color:"#8a7a5a", maxWidth:520, lineHeight:1.6, fontStyle:"italic" }}>
                      "{raceAnalysis.keyRace}"
                    </p>
                  )}
                </div>

                {/* Race scenario + pace */}
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12, marginBottom:18 }}>
                  {[
                    { label:"🏃 Pace Scenario", val:raceAnalysis.paceScenario },
                    { label:"🏁 Track Advantage", val:raceAnalysis.trackAdvantage },
                    { label:"⚠️ Horses to Avoid", val:Array.isArray(raceAnalysis.avoid)?raceAnalysis.avoid.join(" · "):raceAnalysis.avoid },
                  ].map(({label,val})=>(
                    <div key={label} style={{ ...S.card }}>
                      <div style={{ fontSize:10, color:S.gold, textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:6 }}>{label}</div>
                      <div style={{ fontSize:12, color:"#c5b58a", lineHeight:1.5 }}>{val || "—"}</div>
                    </div>
                  ))}
                </div>

                {/* Exotic picks */}
                <div style={{ ...S.card, padding:18, marginBottom:18 }}>
                  <div style={{ fontSize:11, color:S.gold, textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:12 }}>🎰 Exotic Bet Picks</div>
                  <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))", gap:10 }}>
                    {[
                      { label:"Exacta", val:raceAnalysis.exacta?.join(" → ") },
                      { label:"Trifecta", val:raceAnalysis.trifecta?.join(" → ") },
                      { label:"Superfecta", val:raceAnalysis.superfecta?.join(" → ") },
                      { label:"🎯 Longshot Play", val:raceAnalysis.longshot ? `${raceAnalysis.longshot} (${raceAnalysis.longshotOdds})` : null },
                    ].map(({label,val})=>(
                      <div key={label} style={{ background:"rgba(255,255,255,0.03)", borderRadius:6, padding:"10px 12px", border:"1px solid rgba(201,168,76,0.12)" }}>
                        <div style={{ fontSize:9, color:"#8a7a5a", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:4 }}>{label}</div>
                        <div style={{ fontSize:12, color:"#F5E6C8", fontWeight:600 }}>{val || "—"}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Top picks */}
                {raceAnalysis.topPicks?.length > 0 && (
                  <div>
                    <div style={{ fontSize:13, color:S.gold, marginBottom:10, fontWeight:700 }}>📌 Top Picks with Edge Scores</div>
                    <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))", gap:10 }}>
                      {raceAnalysis.topPicks.map((pick, i) => {
                        const h = FIELD.find(x=>x.name===pick.name);
                        const imp = h ? oddsToProb(h.odds) : 0;
                        return (
                          <div key={i} style={{ ...S.card, borderColor:"rgba(201,168,76,0.25)" }}>
                            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:8 }}>
                              <div>
                                <div style={{ fontSize:14, fontWeight:700, color:"#F5E6C8" }}>{pick.name}</div>
                                <div style={{ fontSize:10, color:"#8a7a5a" }}>Post {pick.post || h?.post} · {pick.odds || h?.odds}</div>
                              </div>
                              <div style={{ textAlign:"right" }}>
                                <div style={{ fontSize:18, fontWeight:700, color:pick.edgeScore>=8?"#6BFFB8":pick.edgeScore>=5?"#FFD700":"#C9A84C" }}>
                                  {pick.edgeScore}/10
                                </div>
                                <div style={{ fontSize:9, color:"#5a4a2a" }}>Edge</div>
                              </div>
                            </div>
                            <div style={{ fontSize:11, color:"#8a7a5a", marginBottom:8, lineHeight:1.4 }}>{pick.reason}</div>
                            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                              <span style={{ fontSize:11, color:S.gold, fontWeight:600 }}>Bet: {pick.betType}</span>
                              <button onClick={()=>{
                                setBetForm(p=>({...p, horse:pick.name, betType:pick.betType||"Win", odds:pick.odds||h?.odds||"", note:`AI edge score: ${pick.edgeScore}/10`}));
                                setView("tracker");
                              }} style={{ padding:"3px 10px", borderRadius:4, border:"1px solid rgba(201,168,76,0.3)", background:"rgba(201,168,76,0.08)", color:S.gold, fontSize:10, cursor:"pointer", fontFamily:"Georgia,serif" }}>
                                📊 Log Bet
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {!raceAnalysis && !raceLoading && (
              <div style={{ ...S.card, textAlign:"center", padding:"48px 20px" }}>
                <div style={{ fontSize:48, marginBottom:12 }}>🌹</div>
                <p style={{ color:"#8a7a5a", fontSize:13, marginBottom:18 }}>
                  Run AI analysis on the full 20-horse field to get winner, exotic picks, and pace scenario.
                </p>
                <button onClick={analyzeFullRace} style={{
                  padding:"11px 28px", borderRadius:4,
                  background:"linear-gradient(135deg,#C9A84C,#9a7a2c)",
                  border:"none", color:"#0D0800", fontSize:13, fontWeight:700,
                  cursor:"pointer", fontFamily:"Georgia,serif",
                }}>⚡ Run Full Race Analysis</button>
              </div>
            )}
          </div>
        )}

        {/* ═══ TRACKER VIEW ═══ */}
        {view==="tracker" && (
          <div style={{ maxWidth:920, margin:"0 auto" }}>
            <h2 style={{ margin:"0 0 16px", fontSize:17, color:S.gold }}>📊 Bet Tracker</h2>

            {/* Stats */}
            <div style={{ display:"grid", gridTemplateColumns:"repeat(5,1fr)", gap:1, background:"rgba(255,255,255,0.04)", borderRadius:10, overflow:"hidden", marginBottom:20, border:"1px solid rgba(201,168,76,0.15)" }}>
              {[
                { label:"Total Bets", val:bets.length, color:"#F5E6C8" },
                { label:"Won", val:stats.won, color:"#6BFFB8" },
                { label:"Lost", val:stats.lost, color:"#FF6B6B" },
                { label:"Net Units", val:(stats.net>=0?"+":"")+stats.net.toFixed(2)+"u", color:stats.net>=0?"#6BFFB8":"#FF6B6B" },
                { label:"ROI", val:stats.roi.toFixed(1)+"%", color:stats.roi>=0?"#6BFFB8":"#FF6B6B" },
              ].map(({label,val,color})=>(
                <div key={label} style={{ background:"rgba(255,255,255,0.03)", padding:"12px 10px", textAlign:"center" }}>
                  <div style={{ fontSize:20, fontWeight:700, color, fontFamily:"Georgia,serif" }}>{val}</div>
                  <div style={{ fontSize:9, color:"#5a4a2a", textTransform:"uppercase", letterSpacing:"0.1em", marginTop:3 }}>{label}</div>
                </div>
              ))}
            </div>

            {/* Add bet form */}
            <div style={{ ...S.card, padding:18, marginBottom:20 }}>
              <div style={{ fontSize:11, color:S.gold, fontWeight:700, marginBottom:12, textTransform:"uppercase", letterSpacing:"0.1em" }}>+ Log a Bet</div>
              <div style={{ display:"grid", gridTemplateColumns:"2fr 1fr 1fr 1fr", gap:9, marginBottom:9 }}>
                <div>
                  <label htmlFor="bet-horse" style={S.lbl}>Horse</label>
                  <select id="bet-horse" name="horse" value={betForm.horse} onChange={e=>setBetForm(p=>({...p,horse:e.target.value}))} style={S.inp}>
                    <option value="">Select horse...</option>
                    {FIELD.map(h=><option key={h.post} value={h.name}>Post {h.post}: {h.name} ({h.odds})</option>)}
                  </select>
                </div>
                <div>
                  <label htmlFor="bet-type" style={S.lbl}>Bet Type</label>
                  <select id="bet-type" name="betType" value={betForm.betType} onChange={e=>setBetForm(p=>({...p,betType:e.target.value}))} style={S.inp}>
                    {["Win","Place","Show","Exacta","Trifecta","Superfecta","Win/Place"].map(t=><option key={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label htmlFor="bet-units" style={S.lbl}>Units / $</label>
                  <input id="bet-units" name="units" type="number" value={betForm.units} onChange={e=>setBetForm(p=>({...p,units:e.target.value}))} placeholder="2.00" style={S.inp} />
                </div>
                <div>
                  <label htmlFor="bet-odds" style={S.lbl}>Odds</label>
                  <input id="bet-odds" name="odds" value={betForm.odds} onChange={e=>setBetForm(p=>({...p,odds:e.target.value}))} placeholder="5-1" style={S.inp} />
                </div>
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"3fr 1fr auto", gap:9 }}>
                <div>
                  <label htmlFor="bet-note" style={S.lbl}>Notes</label>
                  <input id="bet-note" name="note" value={betForm.note} onChange={e=>setBetForm(p=>({...p,note:e.target.value}))} placeholder="AI edge score, angle, reason..." style={S.inp} />
                </div>
                <div>
                  <label htmlFor="bet-result" style={S.lbl}>Result</label>
                  <select id="bet-result" name="result" value={betForm.result} onChange={e=>setBetForm(p=>({...p,result:e.target.value}))} style={S.inp}>
                    <option value="pending">Pending</option>
                    <option value="won">Won</option>
                    <option value="lost">Lost</option>
                  </select>
                </div>
                <div style={{ display:"flex", alignItems:"flex-end" }}>
                  <button onClick={addBet} style={{
                    padding:"8px 18px", borderRadius:4,
                    background:"linear-gradient(135deg,#C9A84C,#9a7a2c)",
                    border:"none", color:"#0D0800", fontSize:12, fontWeight:700,
                    cursor:"pointer", fontFamily:"Georgia,serif",
                  }}>Add</button>
                </div>
              </div>
            </div>

            {/* Bets list */}
            {bets.length===0 ? (
              <div style={{ ...S.card, textAlign:"center", padding:"40px 20px" }}>
                <div style={{ fontSize:36, marginBottom:10 }}>🎰</div>
                <p style={{ color:"#8a7a5a", fontSize:12 }}>No bets logged yet. Analyze horses then log your plays here.</p>
              </div>
            ) : (
              <div style={{ display:"flex", flexDirection:"column", gap:7 }}>
                {[...bets].reverse().map(bet=>(
                  <div key={bet.id} style={{
                    ...S.card, display:"flex", alignItems:"center", gap:12, flexWrap:"wrap",
                    borderColor:bet.result==="won"?"rgba(107,255,184,0.25)":bet.result==="lost"?"rgba(255,107,107,0.25)":"rgba(201,168,76,0.15)",
                    background:bet.result==="won"?"rgba(107,255,184,0.04)":bet.result==="lost"?"rgba(255,107,107,0.04)":"rgba(255,255,255,0.03)",
                  }}>
                    <div style={{ width:8, height:8, borderRadius:"50%", flexShrink:0, background:bet.result==="won"?"#6BFFB8":bet.result==="lost"?"#FF6B6B":"#5a4a2a" }} />
                    <div style={{ flex:1, minWidth:140 }}>
                      <div style={{ fontSize:13, fontWeight:700, color:"#F5E6C8" }}>{bet.horse}</div>
                      <div style={{ fontSize:10, color:"#5a4a2a" }}>{bet.betType}</div>
                    </div>
                    <div style={{ textAlign:"center" }}>
                      <div style={{ fontSize:12, color:S.gold, fontWeight:700 }}>{bet.units}u @ {bet.odds||"—"}</div>
                    </div>
                    {bet.note && <div style={{ fontSize:10, color:"#5a4a2a", fontStyle:"italic", flex:1, minWidth:100 }}>{bet.note}</div>}
                    <div style={{ display:"flex", gap:5, flexShrink:0 }}>
                      {["won","lost","pending"].map(r=>(
                        <button key={r} onClick={()=>updateResult(bet.id,r)} style={{
                          padding:"3px 8px", borderRadius:3, border:"1px solid", fontSize:9, cursor:"pointer", fontFamily:"Georgia,serif",
                          fontWeight:bet.result===r?700:400,
                          borderColor:r==="won"?"rgba(107,255,184,0.4)":r==="lost"?"rgba(255,107,107,0.4)":"rgba(255,255,255,0.15)",
                          background:bet.result===r?(r==="won"?"rgba(107,255,184,0.15)":r==="lost"?"rgba(255,107,107,0.15)":"rgba(255,255,255,0.08)"):"transparent",
                          color:r==="won"?"#6BFFB8":r==="lost"?"#FF6B6B":"#8a7a5a",
                        }}>{r}</button>
                      ))}
                      <button onClick={()=>deleteBet(bet.id)} style={{ padding:"3px 7px", borderRadius:3, border:"1px solid rgba(255,80,80,0.2)", background:"transparent", color:"#FF6B6B", fontSize:10, cursor:"pointer" }}>✕</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ── HORSE ANALYSIS CARD ──
function HorseAnalysis({ horse, prediction, onAddBet }) {
  const imp = oddsToProb(horse.odds);
  const aiProb = (prediction.winProbability || 0) / 100;
  const edgePP = (aiProb - imp) * 100;
  const edgeColor = edgePP >= 8 ? "#6BFFB8" : edgePP >= 3 ? "#FFD700" : edgePP < -5 ? "#FF6B6B" : "#C9A84C";
  const edgeLabel = edgePP >= 8 ? "🔥 Strong Edge" : edgePP >= 3 ? "✅ Moderate Edge" : edgePP < -5 ? "⚠️ Overpriced — Fade" : "➖ Fairly Priced";

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
      {/* Header */}
      <div style={{
        textAlign:"center", padding:"24px 16px",
        background:"radial-gradient(ellipse at center,rgba(201,168,76,0.12),rgba(201,168,76,0.02) 70%)",
        border:"1px solid rgba(201,168,76,0.3)", borderRadius:10,
      }}>
        <div style={{ display:"flex", justifyContent:"center", gap:8, alignItems:"center", marginBottom:6 }}>
          <div style={{ width:32, height:32, borderRadius:5, display:"flex", alignItems:"center", justifyContent:"center", background:horse.color+"33", border:`2px solid ${horse.color}88`, fontSize:14, fontWeight:700, color:horse.color }}>{horse.post}</div>
          <h2 style={{ margin:0, fontSize:22, color:"#F5E6C8" }}>{horse.name}</h2>
        </div>
        <div style={{ fontSize:11, color:"#8a7a5a", marginBottom:12 }}>
          {horse.jockey} · {horse.trainer} · {horse.style} · Post {horse.post}
        </div>

        {/* Win probability bar */}
        <div style={{ marginBottom:12 }}>
          <div style={{ display:"flex", justifyContent:"space-between", fontSize:11, color:"#8a7a5a", marginBottom:5 }}>
            <span>AI Win Probability: <strong style={{color:"#F5E6C8"}}>{prediction.winProbability}%</strong></span>
            <span>Market Implied: <strong style={{color:"#F5E6C8"}}>{(imp*100).toFixed(1)}%</strong> ({horse.odds})</span>
          </div>
          <div style={{ height:8, borderRadius:4, background:"rgba(255,255,255,0.08)", overflow:"hidden" }}>
            <div style={{ height:"100%", width:`${Math.min(prediction.winProbability||0,100)}%`, background:`linear-gradient(90deg,${S.gold},#fff8e7)`, borderRadius:4 }} />
          </div>
        </div>

        {/* Edge */}
        <div style={{ display:"inline-flex", alignItems:"center", gap:10, padding:"8px 18px", borderRadius:8, background:"rgba(255,255,255,0.05)", border:"1px solid rgba(201,168,76,0.2)" }}>
          <div>
            <div style={{ fontSize:20, fontWeight:700, color:edgeColor }}>{edgePP>=0?"+":""}{edgePP.toFixed(1)}pp</div>
            <div style={{ fontSize:10, color:edgeColor }}>{edgeLabel}</div>
          </div>
          <div style={{ borderLeft:"1px solid rgba(255,255,255,0.1)", paddingLeft:10 }}>
            <div style={{ fontSize:16, fontWeight:700, color:"#C9A84C" }}>{prediction.edgeRating}/10</div>
            <div style={{ fontSize:10, color:"#8a7a5a" }}>Edge Rating</div>
          </div>
          <div style={{ borderLeft:"1px solid rgba(255,255,255,0.1)", paddingLeft:10 }}>
            <div style={{ fontSize:13, fontWeight:700, color:"#F5E6C8" }}>{prediction.confidence?.toUpperCase()}</div>
            <div style={{ fontSize:10, color:"#8a7a5a" }}>Confidence</div>
          </div>
        </div>
      </div>

      {/* Place/Show prob */}
      {prediction.placeShowProbability > 0 && (
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
          <div style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(201,168,76,0.12)", borderRadius:7, padding:"10px 14px", textAlign:"center" }}>
            <div style={{ fontSize:18, fontWeight:700, color:"#C9A84C" }}>{prediction.winProbability}%</div>
            <div style={{ fontSize:10, color:"#5a4a2a", textTransform:"uppercase", letterSpacing:"0.1em" }}>Win Probability</div>
          </div>
          <div style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(201,168,76,0.12)", borderRadius:7, padding:"10px 14px", textAlign:"center" }}>
            <div style={{ fontSize:18, fontWeight:700, color:"#8a9bb5" }}>{prediction.placeShowProbability}%</div>
            <div style={{ fontSize:10, color:"#5a4a2a", textTransform:"uppercase", letterSpacing:"0.1em" }}>Place / Show</div>
          </div>
        </div>
      )}

      {/* Key factors + concerns */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
        {prediction.keyFactors?.length > 0 && (
          <div style={{ background:"rgba(107,255,184,0.04)", border:"1px solid rgba(107,255,184,0.15)", borderRadius:7, padding:"12px 14px" }}>
            <div style={{ fontSize:10, color:"#6BFFB8", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:7 }}>✅ Key Factors</div>
            {prediction.keyFactors.map((f,i)=>(
              <div key={i} style={{ fontSize:11, color:"#c5d5e8", marginBottom:4, display:"flex", gap:6 }}>
                <span style={{ color:"#6BFFB8", flexShrink:0 }}>+</span>{f}
              </div>
            ))}
          </div>
        )}
        {prediction.concerns?.length > 0 && (
          <div style={{ background:"rgba(255,107,107,0.04)", border:"1px solid rgba(255,107,107,0.15)", borderRadius:7, padding:"12px 14px" }}>
            <div style={{ fontSize:10, color:"#FF6B6B", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:7 }}>⚠️ Concerns</div>
            {prediction.concerns.map((c,i)=>(
              <div key={i} style={{ fontSize:11, color:"#c5d5e8", marginBottom:4, display:"flex", gap:6 }}>
                <span style={{ color:"#FF6B6B", flexShrink:0 }}>−</span>{c}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Track bias */}
      {prediction.trackBias && (
        <div style={{ background:"rgba(201,168,76,0.05)", border:"1px solid rgba(201,168,76,0.15)", borderRadius:7, padding:"11px 14px" }}>
          <div style={{ fontSize:10, color:S.gold, textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:5 }}>🏁 Track Conditions Impact</div>
          <div style={{ fontSize:11, color:"#c5b58a", lineHeight:1.5 }}>{prediction.trackBias}</div>
        </div>
      )}

      {/* Analysis */}
      {prediction.analysis && (
        <div style={{ background:"rgba(0,0,0,0.3)", borderRadius:7, padding:"12px 16px", borderLeft:`3px solid ${S.gold}` }}>
          <p style={{ margin:0, fontSize:12, color:"#c5b58a", lineHeight:1.7, fontStyle:"italic" }}>"{prediction.analysis}"</p>
        </div>
      )}

      {/* Recommended bets + log */}
      {prediction.recommendedBets?.length > 0 && (
        <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
          {prediction.recommendedBets.map(betType=>(
            <button key={betType} onClick={()=>onAddBet({
              horse:horse.name, betType, units:1, odds:horse.odds,
              result:"pending",
              note:`AI edge ${edgePP>=0?"+":""}${edgePP.toFixed(1)}pp · Edge rating ${prediction.edgeRating}/10`,
            })} style={{
              flex:1, minWidth:120, padding:"8px 12px", borderRadius:5, cursor:"pointer",
              background:"rgba(201,168,76,0.08)", border:"1px solid rgba(201,168,76,0.25)",
              color:S.gold, fontSize:11, fontFamily:"Georgia,serif",
            }}>
              📊 Log {betType} bet
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
