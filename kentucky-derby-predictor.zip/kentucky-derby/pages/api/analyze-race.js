// pages/api/analyze-race.js — AI analyzes the full field and picks top contenders
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const { horses, trackCondition, notes } = req.body;

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(500).json({ error: "ANTHROPIC_API_KEY not configured" });

  const fieldSummary = horses.map(h =>
    `Post ${h.post}: ${h.name} (${h.odds}) - ${h.style} - Jockey: ${h.jockey} - Trainer: ${h.trainer}`
  ).join("\n");

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 2000,
        system: `You are a world-class Kentucky Derby handicapper. Analyze the full field and return ONLY valid JSON with no markdown:
{
  "winner": "Horse Name",
  "exacta": ["Horse1", "Horse2"],
  "trifecta": ["Horse1", "Horse2", "Horse3"],
  "longshot": "Horse Name",
  "longshotOdds": "30-1",
  "keyRace": "2-3 sentence race scenario describing how the race will unfold",
  "paceScenario": "description of early pace",
  "trackAdvantage": "which running style benefits from today's conditions",
  "topPicks": [
    {
      "name": "Horse Name",
      "post": 1,
      "reason": "brief reason",
      "betType": "Win" or "Place" or "Exacta",
      "odds": "5-1",
      "edgeScore": 8
    }
  ],
  "avoid": ["Horse to avoid", "reason"],
  "superfecta": ["Horse1","Horse2","Horse3","Horse4"]
}`,
        messages: [{
          role: "user",
          content: `152nd Kentucky Derby - May 2, 2026 - Churchill Downs\nTrack: ${trackCondition}\n${notes ? `Notes: ${notes}\n` : ""}Full field:\n${fieldSummary}\n\nAnalyze this field and provide your top picks, race scenario, and best bets.`,
        }],
      }),
    });

    if (!response.ok) return res.status(response.status).json({ error: await response.text() });
    const data = await response.json();
    const text = data.content?.map(b => b.text || "").join("") || "";
    try {
      return res.status(200).json(JSON.parse(text.replace(/```json|```/g, "").trim()));
    } catch {
      return res.status(200).json({ error: "Parse error", raw: text });
    }
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
