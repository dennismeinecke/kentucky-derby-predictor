// pages/api/predict.js — server-side proxy, key never hits the browser
export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const { prompt } = req.body;
  if (!prompt) return res.status(400).json({ error: "Missing prompt" });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(500).json({ error: "ANTHROPIC_API_KEY not configured in .env.local" });

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1200,
        system: `You are an expert Kentucky Derby handicapper with deep knowledge of horse racing, Beyer Speed Figures, trip handicapping, pedigree analysis, and betting strategy.

When analyzing a Kentucky Derby horse or making predictions, always respond in this exact JSON format with no markdown or extra text:
{
  "winProbability": 15,
  "placeShowProbability": 35,
  "confidence": "high" | "medium" | "low",
  "recommendedBets": ["Win", "Place"] or ["Exacta", "Trifecta"] etc,
  "keyFactors": ["factor 1", "factor 2", "factor 3"],
  "concerns": ["concern 1", "concern 2"],
  "trackBias": "how track conditions affect this horse",
  "analysis": "2-3 sentence expert analysis",
  "edgeRating": 8
}

edgeRating is 1-10 where 10 = strongest betting edge vs current odds.`,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      return res.status(response.status).json({ error: err });
    }

    const data = await response.json();
    const text = data.content?.map(b => b.text || "").join("") || "";
    try {
      return res.status(200).json(JSON.parse(text.replace(/```json|```/g, "").trim()));
    } catch {
      return res.status(200).json({ analysis: text, winProbability: 0, edgeRating: 0, keyFactors: [], concerns: [], recommendedBets: [] });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
}
